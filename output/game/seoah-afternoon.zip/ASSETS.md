# 에셋 출처

| 파일 | 출처 | 용도 |
| --- | --- | --- |
| `assets/characters/seoah-front.png` | OpenAI 내장 `image_gen`, 2026-10-21 직접 생성 | PINOC JST-2 캐릭터 생성용 정면 전신 원본 |

가상의 한국인 25세 여성 캐릭터. 특정 실존 인물의 사진이나 외부 캐릭터 에셋을 사용하지 않았다. 생성 프롬프트는 `docs/character-prompt.txt`에 보관한다.

참고한 작업 방식: https://x.com/akokoi1/status/2112365119187591189
PINOC 연결·기능·비용 안내: https://viggle.ai/pinoc/mcp

## PINOC 동작

공식 무료 동작 라이브러리에서 가져온 `splat-skeleton-glb` 파일. 캐릭터와 호환되는 MetaHuman 뼈대이며 별도 인체 메시를 포함하지 않는다.

| 파일 | 공식 이름 | Asset ID |
| --- | --- | --- |
| `public/motions/idle.glb` | Standing Idle | `1cbf45b5-5abe-4a88-97cd-a1a21da60d7b` |
| `public/motions/walk.glb` | Walking | `32d71c7f-e88a-4d1f-9c0c-1fde2da5f060` |
| `public/motions/run.glb` | Running | `32c1d7ba-29d6-466c-a2bc-56ff17ca4d1a` |

출처: https://viggle.ai/pinoc/app/ — 2026-10-21 MCP로 취득, 동작 비용 0크레딧.

뷰어 엔진: `@viggle/splat-engine@0.2.0` (MIT), `playcanvas@2.18.0` (MIT). 라이선스 원문은 설치 패키지에 포함된다.

## PINOC 캐릭터

`public/characters/seoah.vsplat`: 위에서 생성한 전신 원본을 PINOC(JST-2)에 넣어 정밀 보정 포함으로 생성한 비공개 캐릭터.

- Asset ID: `181332d0-bf2e-461a-807f-d3aabea86605`
- 취득 형식: `high`, 48,000 Gaussian, 1,303,788 bytes
- 생성 비용: 10크레딧
- 생성 결과와 뷰어를 2026-10-21에 확인했다.

## 얼굴 보존·실사감 비교 실험

| 파일 | 출처와 용도 |
| --- | --- |
| `assets/characters/seoah-face-reference.png` | OpenAI 내장 image_gen으로 전신 원본을 참조해 생성한 1024×1536 얼굴 클로즈업. 특정 실존 인물 자료 없음. AI가 추정한 세부이며 원본의 실측 복원본이 아님 |
| `public/characters/seoah-full.vsplat` | 기존 PINOC 자산의 full 단계, 131,072점, 3,546,788 bytes. 점 수 비교용. 추가 생성 비용 없음 |
| `public/characters/seoah-face-reference.vsplat` | 전신 원본+얼굴 참고를 넣은 실험 자산 `a886542f-93bf-4b31-aa69-601c8a692b20`. high 48,000점, 1,303,804 bytes, refine=true, private |
| `output/research/provider-source.png` | PINOC get_asset이 반환한 기존 입력 파일. 기준 원본과 SHA-256 동일 |
| `output/research/provider-preview.webp` | PINOC가 제공한 기존 생성 자산의 미리보기. 로컬 렌더러 이전의 품질 비교용 |
| `output/research/*.png`, `output/verification/*.png` | 격리된 headless Chromium에서 직접 캡처한 비교·검증 화면. 외부 홍보 이미지 아님 |

2026-10-21 실험. [얼굴 생성 프롬프트](docs/face-reference-prompt.txt), [3D 생성 조건](docs/face-reference-experiment.json)을 보관했다. 추가 생성 10크레딧, 잔액 50→40. 이미지 파일과 모델을 실제 저장했으며 만료되는 서명 URL은 앱에 사용하지 않는다.

새 모델은 실사감 개선 성공으로 판정하지 않았다. 비교 선택지로만 보존하고 기존 모델을 기본값으로 유지한다. 외부 에셋 팩이나 실존 인물 스캔은 이번 작업에 사용하지 않았다.

## 여성 일러스트 참고 세트

2026-10-21 OpenAI 내장 `image_gen`으로 새로 제작한 성인 여성 디자인. 기존 실사 사진과 별도의 캐릭터 디자인이며 외부 작가 이미지·실존 인물·기성 캐릭터를 참조하지 않았다.

| 파일 | 출처·역할·확인 |
| --- | --- |
| `assets/characters/seoah-illustration-front.png` | 텍스트로 생성한 정면 전신 기준. 1024×1536, 머리·손·발이 프레임 안에 있고 얼굴·옷·팔다리가 분명하게 읽힘 |
| `assets/characters/seoah-illustration-side.png` | 정면을 참조해 생성한 측면 전신. 1024×1536, 코·턱·머리 볼륨·의상 깊이를 전달하는 보조 참고 |
| `assets/characters/seoah-illustration-back.png` | 정면을 참조해 생성한 후면 전신. 1024×1536, 뒤쪽 머리·재킷·치마의 디자인을 전달하는 보조 참고 |

세 원본을 직접 열어 전체 형태와 선·채색·프레이밍을 확인했다. 어두운 갈색 머리, 아이보리 상의, 청록 치마, 검정 스타킹과 부츠로 색·의상 실루엣을 유지한다. 작은 금속 장식과 자수에는 시점 간 차이가 있어 정면을 우선한다. 보조 시점은 AI 추정이며 정확한 다각도 관측 자료로 취급하지 않는다.

위 3장을 PINOC에 입력해 `public/characters/seoah-illustration.vsplat`을 생성했다. Asset ID `e06238a9-a60d-4856-b335-0a05eccfce8e`, `refine: true`, `visibility: private`, `high` 단계 48,000 Gaussian, 1,303,772 bytes다. 이번 생성 10크레딧, 잔액 40→30. 기존 무료 동작 3개를 재사용했다.

실제 로컬 뷰어에서 정면·측면·후면과 얼굴 확대를 직접 확인했다. 의상과 색·실루엣이 잘 읽히며 대기·걷기·달리기 재생과 모바일 조작을 검증했다. 원본의 미소·머리 장식 위치·뒤쪽 치마 장식·세부 자수는 달라지거나 생략됐다. **동작 시제품용으로 채택하며 정확한 원본 복제로 판정하지 않는다.** 결과 캡처는 `output/illustration/`에 있다. [입력 안내와 결과](docs/illustration-input-guide.md), [생성 기록](docs/illustration-generation.json), `docs/illustration-*-prompt.txt`를 함께 보관한다.

## VR 여성 아바타용 의상 참고 시트

2026-10-21 · `assets/costumes/vr-womenswear-v1/`의 PNG 6장은 OpenAI 내장 `image_gen`으로 직접 생성했다. 외부 이미지나 실존 인물은 사용하지 않았다. 01번 전체 구성을 기준으로 02~05번 세부 시트를 생성했고, 06번 소재 시트에는 01·03번을 함께 참조했다. 프롬프트는 `docs/vr-womenswear-v1/`에 보관한다.

흰 U넥 시스루 긴팔, 빨간 브라·레이스 팬티, 짧은 차콜 A라인 치마, 검정 팬티스타킹, 검정 단화를 정리했다. 전체 구성·상의 구조·레드 이너·치마와 레이어 순서·스타킹과 단화·소재 마감의 6장이다. 직접 이미지로 확인한 범위는 의상 품목, 전체 배색, 구성, 앞뒤 및 확대도, 스타킹 → 레이스 팬티 → 치마 순서다. **의상 디자인 참고 자료로 채택**하며 실제 원단 측정·3D 재질·착용 핏·VR 시야의 검증 자료로 취급하지 않는다.

착용 인물 시트 첫 시도는 이미지 도구의 sexual 안전 필터로 거절되어 인체 없는 제품 시트로 변경했다. 얼굴·체형·착용 전신·1인칭 시점은 아직 없다. [전체 목록](assets/costumes/vr-womenswear-v1/index.html), [기준과 한계](assets/costumes/vr-womenswear-v1/README.md), `output/vr-womenswear-v1/`의 배포 ZIP과 manifest를 함께 보관한다. PINOC를 호출하거나 추가 3D 생성 크레딧을 사용하지 않았다.

## 의상 v2와 단발 여성 캐릭터 참고 세트

2026-10-21 · 후속 요청으로 `assets/costumes/vr-womenswear-v2/`에 의상 6장을, `assets/characters/vr-woman-bob-v1/`에 캐릭터 6장을 저장했다. 내장 `image_gen` 직접 생성·편집이며, 04번 의상 순서는 v1 원본을 그대로 재사용했다. 외부 인물 사진·작가 이미지·기성 캐릭터를 사용하지 않았다.

의상 변경은 깊어진 U넥과 더 얇은 흰 시스루, 컵 전체에 꽃무늬 레이스가 있는 빨간 브라, 앞 리본과 얇은 통밑창의 굽 없는 단화다. 전체 구성 01과 상의 구조 02를 포함해 변경을 반영했다. 신발 뒤쪽 리본 수정 한 번이 도구 필터에 막혀 신발 제품만의 시트를 새로 제작했고, 뒤꿈치 굽 단차도 별도로 수정한 최종 05를 채택했다.

캐릭터는 가상의 25세 성인 한국인 여성, 밝은 피부와 턱 아래 단발, 풍성한 가슴·잘록한 허리·넓은 골반의 체형 방향이다. 얼굴 3각도, 기본 의상의 전신 3면도, 헤어, 표정 6종, 얼굴 확대, 손·네일을 직접 보고 확인했다. 전신의 회색 티셔츠와 바지는 비율 확인용으로 최종 의상 적용본이 아니다. E컵은 디자인 요청이며 이미지로 실측을 검증하지 않았다.

**캐릭터·의상 디자인 참고 자료로 채택**한다. 정확한 다각도 스캔, 의복 패턴, PBR 맵, 3D 리깅 또는 실제 VR 검증 자료로 채택하지 않는다. 장면·각도 간 미세 차이는 각 부위의 상세 시트를 우선한다. 07·11은 1774×887, 나머지는 1536×1024다. [통합 설명](docs/vr-character-reference-v2.md), [12장 보기](output/vr-character-reference-v2/index.html)에 역할·우선순위·남은 작업을 기록했고, 원본 PNG와 프롬프트·해시 manifest를 ZIP에 묶는다. 이번 작업에서 PINOC를 호출하지 않았다.

## 저장·재사용 검토와 착용본 누락

2026-10-21 사용자 지적에 따라 [점검표](docs/vr-reference-review.md)를 작성했다. 저장된 PNG 12개와 기존 ZIP의 해시·CRC·상대 링크가 모두 일치했다. 회색 티셔츠·바지의 체형 초안을 최종 착용본 대신 제시한 누락은 미해결이다. 원래 의상을 입히는 실제 생성 호출이 `moderation_blocked` 입력 필터로 거절되어 새 착용 이미지가 없다.

`output/vr-reference-reviewed/vr-reference-reviewed.zip`은 기존 원본 12개를 재사용해 전달 형식을 보완한 패키지다. 의상, 얼굴·헤어 세부, 체형용 초안을 구분하고 모든 파일 경로를 패키지 내부 상대 경로로 기록했다. 별도 폴더로 풀어 headless Chromium의 데스크톱·모바일 화면에서 12개 PNG 로딩·원본 링크·가로 넘침 없음·페이지 오류 없음을 확인했다. [오프라인 보기](output/vr-reference-reviewed/package/index.html), [검증 기록](output/vr-reference-reviewed/verification.json). 이 검사는 파일 재사용 검사이며 의상 착용이나 3D·VR 완성을 뜻하지 않는다.

## 불투명 상의 착용 대안

2026-10-21 · 사용자의 “일단 되는대로 해봐”에 따라 시스루 상의에서 불투명 니트로 실제 디자인을 변경한 착용 참고 5장을 `assets/characters/vr-woman-opaque-v1/`에 추가했다. 내장 `image_gen` 직접 생성·편집이며, 위의 단발 얼굴·체형과 리본 플랫 시트를 참조했다. 원래 시스루 제품 디자인과 기존 원본은 그대로 보존했다.

| 파일 | 역할·실제 확인 |
| --- | --- |
| `13-outfit-front.png` | 1024×1536 정면. 불투명 흰 U넥 긴팔, 짧은 차콜 치마, 검정 팬티스타킹, 앞 리본 플랫 착용. 어깨는 덮이며 이너는 보이지 않음 |
| `14-outfit-side.png` | 1024×1536 측면. 최초 생성에 생긴 작은 뒤굽을 제거한 최종 편집본. 평평한 밑창과 전체 프레이밍 확인 |
| `15-outfit-back.png` | 1024×1536 후면. 단발·뒤 U넥·치마 뒤 여밈·단화 뒤쪽 확인 |
| `16-first-person-concept.png` | 1024×1536 본인의 몸을 내려다보는 구도 참고. 손·의상·다리·발의 화면상 배치 확인. 실제 VR 또는 카메라 수치 검증 아님 |
| `17-opaque-top-construction.png` | 1536×1024 불투명 상의 앞뒤·봉제·소재. 뒷목선을 착용 후면에 맞춰 낮춘 최종 편집본 |

모든 결과를 직접 이미지로 확인했다. 신체 실측, 숨겨진 속옷 구성, 각도별 미세 비례·재질 일치는 미검증이다. 프롬프트는 `docs/vr-woman-opaque-v1/`, 변경점과 검토는 [사용 안내](docs/vr-reference-opaque-v1-readme.md), [검토 기록](docs/vr-reference-opaque-v1-review.md)에 있다. 원래 의상 완성본으로 취급하지 않는다.

[오프라인 갤러리](output/vr-reference-opaque-v1/package/index.html)와 `output/vr-reference-opaque-v1/vr-reference-opaque-v1.zip`은 신규 5장·기존 12장과 프롬프트를 포함한다. 기존 12개 이미지 해시 보존, ZIP CRC와 원본 해시, 별도 추출 폴더의 17개 이미지 로딩·상대 링크·원본 열기, 데스크톱과 모바일에서 가로 넘침·페이지 오류 없음을 headless Chromium으로 확인했다. 이 캐릭터의 3D 생성·리깅·VR 실행은 수행하지 않았다.

## 키홀넥·뷔스티에 상의 단독 디자인

`assets/costumes/vr-keyhole-bustier-v1/01-keyhole-bustier-top.png`는 후속 의상 요청으로 내장 `image_gen`에서 새로 생성한 제품 시트다. 인물이나 외부 사진을 참조하지 않았다. 타원형 가슴 컷아웃, 불투명 흰 긴팔과 일체형 컵·허리 절개, 컵 위쪽의 붉은 꽃무늬 레이스를 한 상의로 통합했다. 앞·뒤·소재 확대를 직접 보고 구성과 형태를 확인했다. 착용본이나 VR 검증 자료가 아닌 의상 디자인 후보로 보관한다. 프롬프트는 `docs/vr-keyhole-bustier-v1/01-keyhole-bustier-top.prompt.txt`에 저장했다. 기존 원본과 ZIP은 그대로 유지했다.

## 검정·빨강 레이스 뷔스티에 수정본

`assets/costumes/vr-bustier-black-red-v1/01-bustier-top.png`는 위 흰 상의를 참조해 내장 `image_gen`으로 편집한 의상 단독 시트다. 목·어깨 윗부분을 제거하고 소매를 옆의 좁은 연결부로만 이어 붙였으며, 검정·짙은 빨강 배색, 입체적인 큰 컵, 조이는 코르셋 허리, 본 채널·뒤 끈과 풍부한 꽃무늬 레이스를 반영했다. 앞뒤와 연결부 확대를 직접 보고 확인했다. E컵은 형태의 디자인 의도이며 실측 사이즈나 착용 핏은 검증하지 않았다. 프롬프트는 `docs/vr-bustier-black-red-v1/01-bustier-top.prompt.txt`, 이미지 크기·해시는 같은 에셋 폴더의 `manifest.json`에 저장했다.

후속 “ㅇㅇ 이걸로 ㄱㄱ”로 이 상의를 선택했다. 캐릭터 전신에 적용하는 실제 이미지 편집 요청은 `sexual` 입력 필터에 차단되어 새 착용 이미지는 없다. 확정 디자인과 실패한 실행은 [현재 상태](docs/vr-woman-black-red-v1/STATUS.md), `docs/vr-woman-black-red-v1/01-outfit-front.prompt.txt`에 기록했다. 제품 시트 선택을 착용본·3D 제작 완료로 취급하지 않는다.

## 완성된 흰 상의 착용본의 3D 생성

사용자가 “일단 그럼 아까 다 된걸로 해봐”로 완성된 대안을 선택해, `assets/characters/vr-woman-opaque-v1/13-outfit-front.png`, `14-outfit-side.png`, `15-outfit-back.png`를 실제 입력으로 PINOC(JST-2) 3D를 생성했다. 검정·빨강 뷔스티에 이미지나 이전 거절된 요청은 사용하지 않았다.

`public/characters/vr-woman-opaque.vsplat`: Asset ID `ff4dd217-8bf1-45ad-b958-75ce42302006`, `refine: true`, `visibility: private`, `high` 48,000 Gaussian, 1,303,792 bytes. SHA-256 `b33d4b313f5e85bd8be9ff4dc692d8d089299f1f632958939b574f5832493eba`. 1회 생성에 10크레딧을 사용해 잔액은 30→20이다. 기존 무료 동작 3개를 그대로 재사용했다.

로컬 뷰어 기본 모델로 연결하고 정면·측면·후면·얼굴·달리기·모바일 캡처를 직접 확인했다. 기능 검사 7개와 프로덕션 빌드가 통과했다. 단발과 의상 배색·전체 실루엣은 유지되지만 손가락·신발 리본·원단과 스타킹 질감, 얼굴·머리의 작은 표현이 단순화됐다. 동작 시제품으로 채택하며 원본의 정밀 복제나 VR 사용 준비 완료로 판정하지 않는다.

[생성 기록](docs/vr-opaque-generation.json), [사용 방법·검토](docs/vr-opaque-model-readme.md), `output/vr-opaque-3d/`의 실제 렌더·검증 JSON과 `vr-woman-opaque-3d.zip`을 보관한다. ZIP은 모델·동작·원본·설명 묶음이며 일반 메시 GLB/FBX나 웹 앱 전체가 아니다.

## 1인칭 게임 「서아의 오후」 적용

2026-10-22 · `game.html`에서 위의 `vr-woman-opaque.vsplat` 원본과 기존 `idle.glb`, `walk.glb`를 재사용한다. 추가 외부 에셋 다운로드나 유료 생성은 없다. 1인칭용 몸과 거울용 전신이 같은 뼈대를 공유하며, 원본 파일을 바꾸지 않고 1인칭 렌더에서만 머리·목의 점들을 가린다. 실제 몸 내려다보기·거울 정면·회전 화면을 확인했다. 근접 시 모델의 손·신발·원단 세부 한계가 보이며 체험판 용도로 채택한다.

방, 가구, 액자, 식물, 열쇠, 바닥 무늬는 `src/game/room.js`에서 직접 작성한 기하·절차적 재질이다. 발걸음과 알림은 Web Audio로 합성한 짧은 소리이며 외부 녹음이 없다. UI는 시스템 글꼴만 쓴다. PlayCanvas와 Splat Engine은 기존 설치 버전·라이선스를 유지한다. [사용 안내](docs/seoah-game.md), `output/game/`의 실제 렌더와 실행 검증 기록을 참고한다. 헤드셋용 아바타·정밀 인체 메시·VR 실기기 검증 결과로 취급하지 않는다.
